#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

//make free frames array and initialize all but start (os) to 1

//page table has data and valid bit (0 = junk)

//must have free frame to create PA from page table/LA

//LRU[page] may have been used for a previous page so it must be invalidated
//rMap will help keep track of previously used pages/frames
//rMap[?] == page#, LRU[page#] != rMap[?]: invalidate previous page (0)

//finds the index of the first free frame in an array
//a free frame has a value of 0
//if no free frame is found 0 is returned
int findFreeFrame(int arr[], int frameSize){
    int i = 1; //os is arr[0] (reserved)
    while(i < frameSize){
        if(arr[i] == 0){
            return i;
        }
        i++;
    }
    return 0; //default if no free spot located
}

//return min Index in an array (skip 0 index: reserved by OS)
int findMin(int arr[], int frameSize){
    int i = 1;
    int min = arr[1];
    int minIndex = i; //index to return
    while(i < frameSize){ //keep track of min value
        if(arr[i] < min){
            min = arr[i];
            minIndex = i;
        }
        i++;
    }
    return minIndex;
}

//Endian conversion from part 1
void reverseArray(char arr[], int start, int end){
    char temp1;
    char temp2;
    while(start < end){
        temp1 = arr[start];
        temp2 = arr[start+1];
        arr[start] = arr[end-1];
        arr[start+1] = arr[end];
        arr[end-1] = temp1;
        arr[end] = temp2;
        start += 2;
        end -= 2;
    }
}

//Convert an int to an unsigned int (hex)
unsigned int convertToHex(int d){
    char s[5];
    sprintf(s, "%04X", d);
    printf("%s\n", s);
    return (unsigned int) strtol(s, NULL, 16);
}

struct PageTable{
    int fNum;  //frame number
    int valid; //valid bit (1 if valid)
} PageTable;

void main(int argc, char *argv[]){
    if(argc != 6){ //bytesPerPage, SizeVM, SizePM, infile, outfile
        printf("Incorrect number of arguments passed\n");
        return;
    }
    
    //Open files and check for errors
    FILE *infile = fopen(argv[4], "rb");
    FILE *outfile = fopen(argv[5], "wb");
    if(infile == NULL || outfile == NULL){
        printf("Error with files\n");
        fclose(infile);
        fclose(outfile);
        return;
    }

    int physMem = (int) log2((double) atoi(argv[3])); //physical memory
    int virtMem = (int) log2((double) atoi(argv[2])); //virtual memory
    int bytesPg = (int) log2((double) atoi(argv[1])); //offset
    printf("PM: %d\nVM: %d\nBPg: %d\n", physMem, virtMem, bytesPg);

    int numPages = virtMem - bytesPg; //number pages PT
    int numFrames = physMem - bytesPg; //physical frames
    int offset = bytesPg; //offset

    int CLK = 0; //tick tock
    int faultCount = 0; //count number of faults

    //initialize freeFrame, LRU counter and rMap
    int freeFrameSize = 8; //PT3 change
    int x;                        //value used for looping through for loops
    int freeFrame[freeFrameSize]; //array of free frames (0 if free)
    int LRU[freeFrameSize];       //array of when frame was last used counter (LRU[frame] == count)
    int rMap[freeFrameSize];      //array of previously used frames at LRU's index
    for(x = 0; x < freeFrameSize; x++){
        if(x == 0){
            LRU[x] = 0;
        }
        else{
            LRU[x] = 1;
        }
        freeFrame[x] = 0;
        rMap[x] = 0; //initialize all of rMap to 0
    }

    int ptSize = numPages; //ptSize = sizeVM - offset
    struct PageTable PTArr[ptSize];
    for(x = 0; x < ptSize; x++){
        PTArr[x].valid = 0; //initialize valid bit to be invalid (0)
    }

    int bitSize = 8; //
    unsigned int PT[32] = {2, 4, 1, 7, 3, 5, 6, 0}; //fNum = PT[pNum]
    unsigned long LA;
    unsigned long PA;
    unsigned int p = virtMem - bytesPg; //page table bits
    unsigned int f = 3; //physical frame bits
    //unsigned int d = (unsigned int) bytesPg; //offset bits
    unsigned int d = convertToHex(bytesPg);
    unsigned int pNum, fNum, dNum; //keep track of current spot in array

    unsigned char buffer[bitSize];
    while(fread(buffer, bitSize, 1, infile)){
        CLK++; //increment clock
        int i;
        char converted[bitSize*2 + 1];
        //printf("Read: "); 
        for(i = 0; i < bitSize; i++){
            //printf("%x", buffer[i]); //read bytes from file
            // file deepcode ignore BufferOverflowUnsafeFunction: <N/A>
            sprintf(&converted[i*2], "%02X", buffer[i]); //store bytes from file
        }
        //printf("\n");
        //printf("Before: %s\n", converted);
        int j;
        reverseArray(converted, 0, (bitSize*2));
        char address[bitSize*2 + 1];
        int k = 0;
        //printf("Address:  ");
        for(j = 0; j < bitSize*2 + 1; j++){
            if(converted[j] == '\0'){
                continue;
            }
            else{//printf and store the converted address for later
                //printf("%c", converted[j]);
                sprintf(&address[k], "%c", converted[j]);
                k++;
            }
        }
        //printf("\n");
        //Code for each address
        unsigned long temp = strtol(address, NULL, 16);

        printf("d: %lx\n", d);

        //find dNum
        dNum = temp & d; //redo this math
        printf("Temp: %lx\n", temp);
        printf("dNum: %lx\n", dNum);
        
        //find pNum
        pNum = temp >> d;
        printf("pNum: %d\n", pNum);
        //find fNum
        //fNum = PT[pNum];
        //find PA
        //PA = (fNum << d) + dNum;
        //printf("PA: %lx\n", PA); //Print for debugging
        
        //Page table is set to invalid (0) first then changed to valid when frame is allocated for it
        if(PTArr[pNum].valid == 1){ //valid
            fNum = PTArr[pNum].fNum;
            PA = (fNum << d) + dNum;
            LRU[fNum] = CLK; //keep track of last time used
            //printf("PA: %lx\n", PA);
            fwrite(&PA, sizeof(PA), 1, outfile);
        }
        else{ //not valid
            //find a free frame
            int free = findFreeFrame(freeFrame, freeFrameSize); //returns index of free frame
            faultCount++; //increment fault count when PT is invalid
            if(free > 0){ //free frame located
                PTArr[pNum].fNum = free;
                PTArr[pNum].valid = 1;
                //Set Frame as no longer free
                freeFrame[free] = 1;
                //update rMap array
                rMap[free] = pNum; //rMap[free frame index] = pNum
                //Calculations
                fNum = PTArr[pNum].fNum;
                PA = (fNum << d) + dNum;
                LRU[fNum] = CLK; //keep track of last time used
                //printf("PA: %lx\n", PA);
                fwrite(&PA, sizeof(PA), 1, outfile);
            }
            else{ //no free frame
                int lruIndex = findMin(LRU, freeFrameSize); //returns index of min value
                PTArr[rMap[lruIndex]].valid = 0;  //rMap[lruIndex] == page#
                PTArr[pNum].fNum = lruIndex;
                PTArr[pNum].valid = 1;
                fNum = PTArr[pNum].fNum;
                PA = (fNum << d) + dNum;
                //printf("PA: %lx\n", PA);
                fwrite(&PA, sizeof(PA), 1, outfile);
                LRU[fNum] = CLK; //set clock for current
                rMap[fNum] = pNum;
            }
            
        }

    } //End while(read LA)

    printf("Faults: %d\n", faultCount); //print total fault counts

    fclose(infile);
    fclose(outfile);

    return;

}