#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void reverseArray(char arr[], int start, int end){
    char temp1;
    char temp2;
    while(start < end){
        temp1 = arr[start];
        temp2 = arr[start+1];
        arr[start] = arr[end-1];
        arr[start+1] = arr[end];
        arr[end-1] = temp1;
        arr[end] = temp2;
        start += 2;
        end -= 2;
    }
}

void main(int argc, char *argv[]){
    int bitSize = 8;
    unsigned int PT[32] = {2, 4, 1, 7, 3, 5, 6, 0}; //fNum = PT[pNum]
    unsigned long LA;
    unsigned long PA;
    unsigned int p = 5; //page table bits
    unsigned int f = 3; //physical frame bits
    unsigned int d = 7; //offset bits
    unsigned int pNum, fNum, dNum; //keep track of current spot in array
    //LA = 000000000000abcd
    //LA = 000000000000pN|dN    (5bits|7bits)
    //LA = 00000000000001CC     1|1100|1100
    //LA = 0000000000000(03|4C) 0|0011|0100|1100

    if(argc != 3){ //infile, outfile
        printf("Incorrect number of arguments passed\n");
        return;
    }
    FILE *infile = fopen(argv[1], "rb");
    FILE *outfile = fopen(argv[2], "wb");
    if(infile == NULL || outfile == NULL){
        printf("Error with files\n");
        fclose(infile);
        fclose(outfile);
        return;
    }
    unsigned char buffer[bitSize];
    while(fread(buffer, bitSize, 1, infile)){
        int i;
        char converted[bitSize*2 + 1];
        //printf("Read: "); 
        for(i = 0; i < bitSize; i++){
            //printf("%x", buffer[i]); //read bytes from file
            // file deepcode ignore BufferOverflowUnsafeFunction: <N/A>
            sprintf(&converted[i*2], "%02X", buffer[i]); //store bytes from file
        }
        //printf("\n");
        //printf("Before: %s\n", converted);
        int j;
        reverseArray(converted, 0, (bitSize*2));
        char address[bitSize*2 + 1];
        int k = 0;
        //printf("Address:  ");
        for(j = 0; j < bitSize*2 + 1; j++){
            if(converted[j] == '\0'){
                continue;
            }
            else{//printf and store the converted address for later
                //printf("%c", converted[j]);
                sprintf(&address[k], "%c", converted[j]);
                k++;
            }
        }
        //printf("\n");
        //Code for each address
        //find dNum
        unsigned long temp = strtol(address, NULL, 16);
        dNum = temp & 0x7F;
        //find pNum
        pNum = temp >> d;
        //find fNum
        fNum = PT[pNum];
        //find PA
        PA = (fNum << d) + dNum;
        //printf("PA: %lx\n", PA);
        fwrite(&PA, sizeof(PA), 1, outfile);

    }

    fclose(infile);
    fclose(outfile);
    return;
}